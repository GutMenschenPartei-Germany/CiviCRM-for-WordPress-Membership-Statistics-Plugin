# Shortcodes für die Website

Alle Auswertungen zeigen ausschließlich Summen und Prozentwerte, keine
Einzeldaten. Sie sind für alle Besucher sichtbar.

## Die 13 gewünschten Auswertungen

| Nr. | Auswertung | Shortcode |
|-----|------------|-----------|
| 1 | Anzahl Mitglieder | `[cmst_stat typ="gesamt"]` |
| 2 | Geschlecht (aus An-Rede) | `[cmst_stat typ="geschlecht"]` |
| 3 | Staatsbürgerschaften | `[cmst_stat typ="feld" id="10"]` |
| 3b | dieselben, einzeln gezählt | `[cmst_stat typ="feld" id="10" mehrfach="einzeln"]` |
| 4 | Medianalter und Spanne | `[cmst_stat typ="alter"]` |
| 5 | Bundesländer | `[cmst_stat typ="bundesland"]` |
| 6 | Bildungsabschluss | `[cmst_stat typ="feld" id="14"]` |
| 7 | Berufe | `[cmst_stat typ="feld" id="9" top="10"]` |
| 8 | Klassenzugehörigkeit | `[cmst_stat typ="feld" id="15"]` |
| 9 | Religionszugehörigkeit | `[cmst_stat typ="feld" id="20"]` |
| 10 | ADHS | `[cmst_stat typ="feld" id="16"]` |
| 11 | Autismus | `[cmst_stat typ="feld" id="17"]` |
| 12 | Dunkle Triade | `[cmst_stat typ="feld" id="18"]` |
| 13 | Sexuelle Orientierung | `[cmst_stat typ="feld" id="19"]` |

Weitere verfügbare Werte für `typ`: `mitgliedschaften`, `status`, `anrede`
(zeigt „Herr“/„Frau“ unverändert statt „männlich“/„weiblich“).
Weitere Feld-IDs: `24` (Titel), `12` (Geburtsdatum, besser über `typ="alter"`
ansprechen).

`typ="geschlecht"` wertet das Feld An-Rede (ID 11) aus und übersetzt „Herr“ in
„männlich“ und „Frau“ in „weiblich“. Weitere Zuordnungen lassen sich über den
Filter `cmst_salutation_gender_map` ergänzen.

## Alle Parameter

| Parameter | Standard | Bedeutung |
|-----------|----------|-----------|
| `typ` | `gesamt` | Welche Auswertung (siehe oben) |
| `id` | – | Feld-ID, nur bei `typ="feld"` |
| `format` | `tabelle` | `tabelle`, `liste`, `text`, `zahl` |
| `titel` | Feldname | Eigene Überschrift, `-` blendet sie aus |
| `top` | `0` | Nur die N häufigsten, Rest als „Sonstige“ |
| `min` | global | Ausprägungen unter N werden zusammengefasst |
| `leere` | `nein` | `ja` zeigt auch „Keine Angabe“ |
| `mehrfach` | `kombination` | Bei Mehrfachauswahl: `kombination` zählt „Deutschland und USA“ als eigene Kategorie, `einzeln` zählt jede Nennung separat |

## Beispiele

Große Zahl für einen Hero-Bereich:

    [cmst_stat typ="gesamt" titel="Wir sind"]

Kompakte Liste ohne Überschrift:

    [cmst_stat typ="bundesland" format="liste" titel="-"]

Mitten im Fließtext:

    Unsere Mitglieder verteilen sich auf [cmst_stat typ="geschlecht" format="text"].

Sensibles Feld mit Zusammenfassung kleiner Gruppen:

    [cmst_stat typ="feld" id="19" min="5"]

Berufe auf die zehn häufigsten begrenzt:

    [cmst_stat typ="feld" id="9" top="10" format="liste"]

## Datenschutz

Die Felder 9, 10, 16, 17, 18, 19 und 20 betreffen besondere Kategorien
personenbezogener Daten nach Art. 9 DSGVO. Bei kleinen Mitgliederzahlen können
Prozentangaben Rückschlüsse auf einzelne Personen zulassen.

Empfehlung: global eine Mindestgröße setzen, bevor diese Felder öffentlich
sichtbar werden.

```php
add_filter( 'cmst_min_cell_size', function () {
	return 5;
} );
```

## Zwischenspeicher

Die Zahlen werden 15 Minuten zwischengespeichert. Sofort aktualisieren lassen
sie sich über den Button auf der Seite „Mitglieder-Statistik“ im WP-Backend.

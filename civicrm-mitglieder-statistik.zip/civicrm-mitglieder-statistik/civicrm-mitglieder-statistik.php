<?php
/**
 * Plugin Name:       CiviCRM Mitglieder-Statistik
 * Plugin URI:        https://gut-menschen-partei.de/
 * Description:       Wertet CiviCRM-Mitgliedschaften (Status Neu, Aktuell, Unerledigt) aus und zeigt die Verteilung der benutzerdefinierten Felder aus „Zusätzliche Mitgliedsdaten“ inklusive Altersauswertung.
 * Version:           1.8.1
 * Requires at least: 6.0
 * Requires PHP:      7.4
 * Author:            Gut-Menschen-Partei
 * License:           AGPL-3.0-or-later
 * License URI:       https://www.gnu.org/licenses/agpl-3.0.html
 * Text Domain:       cmst
 */

/*
 * CiviCRM Mitglieder-Statistik
 * Copyright (C) 2026 Gut-Menschen-Partei
 *
 * Dieses Programm ist freie Software: Sie können es unter den Bedingungen
 * der GNU Affero General Public License, wie von der Free Software
 * Foundation veröffentlicht, weitergeben und/oder verändern – entweder
 * gemäß Version 3 der Lizenz oder (nach Ihrer Wahl) jeder späteren Version.
 *
 * Die Veröffentlichung erfolgt in der Hoffnung, dass es Ihnen von Nutzen
 * sein wird, aber OHNE IRGENDEINE GARANTIE – sogar ohne die implizite
 * Garantie der MARKTREIFE oder der EIGNUNG FÜR EINEN BESTIMMTEN ZWECK.
 * Details finden Sie in der GNU Affero General Public License.
 *
 * Sie sollten eine Kopie der GNU Affero General Public License zusammen
 * mit diesem Programm erhalten haben (Datei LICENSE). Falls nicht, siehe
 * <https://www.gnu.org/licenses/>.
 *
 * Hinweis nach § 13 AGPL: Dieses Plugin liefert seine Ausgabe über eine
 * Website aus. Wer eine veränderte Fassung betreibt, muss den Nutzenden
 * dieser Website den Quelltext der veränderten Fassung zugänglich machen.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class CMST_Mitglieder_Statistik {

	const VERSION       = '1.8.1';
	const CACHE_KEY     = 'cmst_report_data';
	const CACHE_TTL     = 900; // 15 Minuten
	const CUSTOM_GROUP  = 2;   // Feldgruppe „Zusätzliche Mitgliedsdaten“
	const SALUTATION_ID = 11;  // Feld „An-Rede“, Quelle für die Geschlechterverteilung
	const MENU_SLUG     = 'cmst-mitglieder-statistik';

	/**
	 * Die auszuwertenden Felder in der gewünschten Reihenfolge.
	 * Schlüssel = CustomField-ID, Wert = Auswertungsmodus.
	 *
	 * 'auto' – Verteilung über die Feldwerte (erkennt Mehrfachauswahl selbst)
	 * 'age'  – Datumsfeld, wird als Altersverteilung ausgewertet
	 */
	private static function field_map() {
		return array(
			11 => 'auto', // An-Rede
			24 => 'auto', // Titel
			10 => 'auto', // Staats-Angehörig-Keit:en
			12 => 'age',  // Geburts-Datum
			14 => 'auto', // Höchster Bildungs-Ab-Schluss
			9  => 'auto', // Beruf
			15 => 'auto', // Klassen-Zugehörig-Keit
			20 => 'auto', // Religions-Haltungs-Zugehörig-Keit
			16 => 'auto', // Neuro-Diversität – ADHS
			17 => 'auto', // Neuro-Diversität – Aut-Ismus
			18 => 'auto', // Neuro-Diversität – Dunkle Triade
			19 => 'auto', // Sexuelle Orientierung
		);
	}

	/** Altersklassen: Untergrenze => Beschriftung. */
	private static function age_brackets() {
		return array(
			0  => 'unter 18',
			18 => '18–24',
			25 => '25–34',
			35 => '35–44',
			45 => '45–54',
			55 => '55–64',
			65 => '65–74',
			75 => '75 und älter',
		);
	}

	public static function init() {
		add_action( 'admin_menu', array( __CLASS__, 'register_menu' ) );
		add_action( 'wp_dashboard_setup', array( __CLASS__, 'register_dashboard_widget' ) );
		add_action( 'admin_post_cmst_refresh', array( __CLASS__, 'handle_refresh' ) );
		add_shortcode( 'civicrm_mitglieder_statistik', array( __CLASS__, 'shortcode' ) );
		add_shortcode( 'cmst_stat', array( __CLASS__, 'shortcode_stat' ) );
	}

	/** Wer darf die Auswertung sehen. Über den Filter anpassbar. */
	private static function capability() {
		return apply_filters( 'cmst_capability', 'manage_options' );
	}

	/**
	 * Kleinste Zellengröße. Werte darunter werden zusammengefasst, damit sich
	 * aus einer Auswertung keine einzelne Person zurückrechnen lässt.
	 * 0 = aus. Bei Feldern wie Religion oder sexueller Orientierung
	 * (DSGVO Art. 9) ist ein Wert von 3–5 empfehlenswert.
	 */
	private static function min_cell_size() {
		return (int) apply_filters( 'cmst_min_cell_size', 0 );
	}

	// ---------------------------------------------------------------------
	// Datenbeschaffung
	// ---------------------------------------------------------------------

	/**
	 * Liefert die Auswertung – aus dem Cache, sonst frisch aus CiviCRM.
	 *
	 * @return array|WP_Error
	 */
	public static function get_data( $force = false ) {
		if ( ! $force ) {
			$cached = get_transient( self::CACHE_KEY );
			if ( is_array( $cached ) ) {
				return $cached;
			}
		}

		$data = self::collect_data();

		if ( ! is_wp_error( $data ) ) {
			set_transient( self::CACHE_KEY, $data, self::CACHE_TTL );
		}

		return $data;
	}

	/**
	 * Holt die Rohdaten aus CiviCRM und rechnet sie zusammen.
	 *
	 * @return array|WP_Error
	 */
	private static function collect_data() {
		if ( ! function_exists( 'civicrm_initialize' ) ) {
			return new WP_Error( 'cmst_no_civicrm', 'CiviCRM ist nicht aktiv. Aktiviere das CiviCRM-Plugin und lade die Seite neu.' );
		}

		try {
			civicrm_initialize();

			$status_ids = self::resolve_status_ids();
			if ( empty( $status_ids['ids'] ) ) {
				return new WP_Error( 'cmst_no_status', 'Die Mitgliedschaftsstatus „Neu“, „Aktuell“ und „Unerledigt“ wurden nicht gefunden. Prüfe Administration → Mitgliedschaftsstatus.' );
			}

			$resolved = self::resolve_fields();

			if ( ! empty( $resolved['error'] ) ) {
				return new WP_Error( 'cmst_field_group', $resolved['error'] );
			}

			$fields = $resolved['fields'];

			if ( empty( $fields ) ) {
				return new WP_Error(
					'cmst_no_fields',
					sprintf(
						'In der Feldgruppe mit der ID %d wurden keine der angegebenen Felder gefunden. Prüfe Administration → Benutzerdefinierte Daten.',
						self::CUSTOM_GROUP
					)
				);
			}

			$rows       = self::fetch_memberships( $fields, $status_ids['ids'], $has_extras );
			$lookups    = self::build_lookups( $fields );
			$min_cell   = self::min_cell_size();
			$total      = count( $rows );
			$contacts   = array();
			$by_status  = array();
			$by_state   = array();
			$by_gender  = array();
			$collectors = array();

			foreach ( $fields as $field ) {
				$collectors[ $field['id'] ] = array(
					'values' => array(),
					'combos' => array(),
					'ages'   => array(),
					'filled' => 0,
					'empty'  => 0,
				);
			}

			foreach ( $rows as $row ) {
				if ( ! empty( $row['contact_id'] ) ) {
					$contacts[ $row['contact_id'] ] = true;
				}

				$status = self::first_scalar( $row, 'status_id:label', 'status_id' );
				$status = ( '' === $status ) ? 'Ohne Status' : $status;
				self::bump( $by_status, $status );

				if ( $has_extras ) {
					$state = self::first_scalar( $row, 'contact_id.address_primary.state_province_id:label' );
					$state = ( '' === $state ) ? 'Keine Angabe' : $state;
					self::bump( $by_state, $state );

					$gender = self::first_scalar( $row, 'contact_id.gender_id:label' );
					$gender = ( '' === $gender ) ? 'Keine Angabe' : $gender;
					self::bump( $by_gender, $gender );
				}

				foreach ( $fields as $field ) {
					$id  = $field['id'];
					$raw = isset( $row[ $field['key'] ] ) ? $row[ $field['key'] ] : null;

					if ( 'age' === $field['mode'] ) {
						$age = self::age_from_date( is_array( $raw ) ? reset( $raw ) : $raw );
						if ( null === $age ) {
							$collectors[ $id ]['empty']++;
						} else {
							$collectors[ $id ]['filled']++;
							$collectors[ $id ]['ages'][] = $age;
							self::bump( $collectors[ $id ]['values'], self::age_bracket( $age ) );
						}
						continue;
					}

					$value = isset( $row[ $field['key'] . ':label' ] )
						? $row[ $field['key'] . ':label' ]
						: $raw;

					$parts = self::normalise( $value );

					if ( isset( $lookups[ $field['data_type'] ] ) ) {
						$parts = self::apply_lookup( $parts, $lookups[ $field['data_type'] ] );
					}

					if ( empty( $parts ) ) {
						$collectors[ $id ]['empty']++;
						continue;
					}

					$collectors[ $id ]['filled']++;

					// Einzelnennungen …
					foreach ( $parts as $part ) {
						self::bump( $collectors[ $id ]['values'], $part );
					}

					// … und zusätzlich die Kombination als eigene Kategorie.
					$combo = $parts;
					sort( $combo, SORT_NATURAL | SORT_FLAG_CASE );
					self::bump( $collectors[ $id ]['combos'], implode( ' und ', $combo ) );
				}
			}

			// Ergebnis zusammenbauen.
			$result_fields = array();
			foreach ( $fields as $field ) {
				$c     = $collectors[ $field['id'] ];
				$entry = array(
					'id'       => $field['id'],
					'label'    => $field['label'],
					'mode'     => $field['mode'],
					'multiple' => ! empty( $field['serialize'] ),
					'filled'   => $c['filled'],
					'empty'    => $c['empty'],
					'values'   => self::sort_and_suppress( $c['values'], $min_cell ),
					'combos'   => self::sort_and_suppress( $c['combos'], $min_cell ),
				);

				if ( 'age' === $field['mode'] ) {
					$entry['values']  = self::sort_by_bracket( $c['values'] );
					$entry['average'] = $c['ages'] ? round( array_sum( $c['ages'] ) / count( $c['ages'] ), 1 ) : null;
					$entry['median']  = self::median( $c['ages'] );
					$entry['min']     = $c['ages'] ? min( $c['ages'] ) : null;
					$entry['max']     = $c['ages'] ? max( $c['ages'] ) : null;
				}

				$result_fields[] = $entry;
			}

			arsort( $by_status );
			$by_state  = self::sort_and_suppress( $by_state, 0 );
			$by_gender = self::sort_and_suppress( $by_gender, 0 );

			return array(
				'generated'         => time(),
				'total_memberships' => $total,
				'total_contacts'    => count( $contacts ),
				'attaches_to'       => $resolved['attaches_to'],
				'group_title'       => $resolved['group_title'],
				'status_labels'     => $status_ids['labels'],
				'by_status'         => $by_status,
				'by_state'          => $has_extras ? $by_state : null,
				'by_gender'         => $has_extras ? $by_gender : null,
				'fields'            => $result_fields,
				'min_cell'          => $min_cell,
			);

		} catch ( \Throwable $e ) {
			return new WP_Error( 'cmst_api_error', 'CiviCRM meldet: ' . $e->getMessage() );
		}
	}

	/** Ermittelt die IDs der drei gewünschten Status – über Name oder Beschriftung. */
	private static function resolve_status_ids() {
		$wanted_names  = array( 'new', 'current', 'pending' );
		$wanted_labels = array( 'neu', 'aktuell', 'unerledigt' );

		$statuses = \Civi\Api4\MembershipStatus::get( false )
			->addSelect( 'id', 'name', 'label' )
			->addWhere( 'is_active', '=', true )
			->execute();

		$ids    = array();
		$labels = array();

		foreach ( $statuses as $status ) {
			$name  = strtolower( (string) $status['name'] );
			$label = self::lower( (string) $status['label'] );

			if ( in_array( $name, $wanted_names, true ) || in_array( $label, $wanted_labels, true ) ) {
				$ids[]    = (int) $status['id'];
				$labels[] = $status['label'];
			}
		}

		return array(
			'ids'    => $ids,
			'labels' => $labels,
		);
	}

	/**
	 * Liest die Metadaten der Felder und baut die APIv4-Feldschlüssel.
	 *
	 * Die Feldgruppe kann entweder an der Mitgliedschaft hängen (Schlüssel:
	 * „Gruppe.Feld“) oder am Kontakt (Schlüssel: „contact_id.Gruppe.Feld“).
	 * Welcher Fall vorliegt, ermitteln wir hier selbst.
	 *
	 * @return array Mit 'fields' und 'attaches_to' – oder mit 'error'.
	 */
	private static function resolve_fields() {
		$map = self::field_map();

		$group = \Civi\Api4\CustomGroup::get( false )
			->addSelect( 'id', 'name', 'title', 'extends', 'is_multiple' )
			->addWhere( 'id', '=', self::CUSTOM_GROUP )
			->execute()
			->first();

		if ( empty( $group ) ) {
			return array(
				'error' => sprintf( 'Es gibt keine benutzerdefinierte Feldgruppe mit der ID %d.', self::CUSTOM_GROUP ),
			);
		}

		if ( ! empty( $group['is_multiple'] ) ) {
			return array(
				'error' => sprintf(
					'Die Feldgruppe „%s“ ist auf „Mehrere Datensätze“ eingestellt. Solche Gruppen sind in CiviCRM eine eigene Entität und lassen sich nicht in einem Rutsch mit den Mitgliedschaften abfragen.',
					$group['title']
				),
			);
		}

		$contact_types = array( 'Contact', 'Individual', 'Organization', 'Household' );

		if ( 'Membership' === $group['extends'] ) {
			$attaches_to = 'membership';
			$prefix      = '';
		} elseif ( in_array( $group['extends'], $contact_types, true ) ) {
			$attaches_to = 'contact';
			$prefix      = 'contact_id.';
		} else {
			return array(
				'error' => sprintf(
					'Die Feldgruppe „%s“ ist an „%s“ gebunden. Ausgewertet werden können nur Gruppen, die am Kontakt oder an der Mitgliedschaft hängen.',
					$group['title'],
					$group['extends']
				),
			);
		}

		$records = \Civi\Api4\CustomField::get( false )
			->addSelect( 'id', 'name', 'label', 'data_type', 'html_type', 'serialize', 'option_group_id' )
			->addWhere( 'custom_group_id', '=', self::CUSTOM_GROUP )
			->addWhere( 'id', 'IN', array_keys( $map ) )
			->execute();

		$by_id = array();
		foreach ( $records as $record ) {
			$by_id[ (int) $record['id'] ] = $record;
		}

		$fields = array();
		foreach ( $map as $id => $mode ) {
			if ( ! isset( $by_id[ $id ] ) ) {
				continue; // Feld existiert nicht (mehr) – still überspringen.
			}
			$record   = $by_id[ $id ];
			$fields[] = array(
				'id'        => $id,
				'mode'      => $mode,
				'label'     => $record['label'],
				'key'       => $prefix . $group['name'] . '.' . $record['name'],
				'data_type' => $record['data_type'],
				'serialize' => $record['serialize'],
				'options'   => ! empty( $record['option_group_id'] ),
			);
		}

		return array(
			'fields'      => $fields,
			'attaches_to' => $attaches_to,
			'group_title' => $group['title'],
		);
	}

	/**
	 * Holt alle Mitgliedschaften in einem Rutsch.
	 *
	 * @param bool $has_extras Wird auf false gesetzt, falls die Kontakt-Joins scheitern.
	 */
	private static function fetch_memberships( array $fields, array $status_ids, &$has_extras ) {
		$extras = array(
			'contact_id.address_primary.state_province_id:label',
			'contact_id.gender_id:label',
		);

		$base_select = array( 'id', 'contact_id', 'status_id:label', 'membership_type_id:label' );
		foreach ( $fields as $field ) {
			$base_select[] = $field['key'];
			if ( $field['options'] ) {
				$base_select[] = $field['key'] . ':label';
			}
		}

		$has_extras = true;

		try {
			return self::run_query( array_merge( $base_select, $extras ), $status_ids );
		} catch ( \Throwable $e ) {
			// Ältere CiviCRM-Versionen kennen die impliziten Kontakt-Joins nicht.
			$has_extras = false;
			return self::run_query( $base_select, $status_ids );
		}
	}

	private static function run_query( array $select, array $status_ids ) {
		$query = \Civi\Api4\Membership::get( false )
			->setSelect( $select )
			->addWhere( 'status_id', 'IN', $status_ids )
			->addWhere( 'is_test', '=', false )
			->addWhere( 'contact_id.is_deleted', '=', false )
			->setLimit( 0 );

		return (array) $query->execute()->getArrayCopy();
	}

	// ---------------------------------------------------------------------
	// Hilfsfunktionen für die Auswertung
	// ---------------------------------------------------------------------

	/**
	 * Baut Nachschlagetabellen für Feldtypen, die auf CiviCRM-Stammtabellen
	 * verweisen statt auf eine Optionsliste – aktuell Land und Bundesland.
	 * Diese Felder liefern in der API nur numerische IDs.
	 */
	private static function build_lookups( array $fields ) {
		$needed = array();

		foreach ( $fields as $field ) {
			if ( in_array( $field['data_type'], array( 'Country', 'StateProvince' ), true ) ) {
				$needed[ $field['data_type'] ] = true;
			}
		}

		$lookups = array();

		if ( isset( $needed['Country'] ) ) {
			$lookups['Country'] = self::reference_labels( 'country' );
		}

		if ( isset( $needed['StateProvince'] ) ) {
			$lookups['StateProvince'] = self::reference_labels( 'stateProvince' );
		}

		return $lookups;
	}

	/**
	 * Holt die übersetzten Bezeichnungen. Bevorzugt über CiviCRMs eigene
	 * Liste, damit die Namen in der Sprache der Installation erscheinen.
	 */
	private static function reference_labels( $kind ) {
		try {
			if ( 'country' === $kind && method_exists( 'CRM_Core_PseudoConstant', 'country' ) ) {
				// Zweiter Parameter false: auch Länder außerhalb der Länderbegrenzung.
				$list = CRM_Core_PseudoConstant::country( false, false );
			} elseif ( 'stateProvince' === $kind && method_exists( 'CRM_Core_PseudoConstant', 'stateProvince' ) ) {
				$list = CRM_Core_PseudoConstant::stateProvince( false, false );
			} else {
				$list = null;
			}

			if ( is_array( $list ) && ! empty( $list ) ) {
				return $list;
			}
		} catch ( \Throwable $e ) {
			// Weiter mit dem API-Fallback.
		}

		$out = array();

		try {
			$entity  = ( 'country' === $kind ) ? '\Civi\Api4\Country' : '\Civi\Api4\StateProvince';
			$records = call_user_func( array( $entity, 'get' ), false )
				->addSelect( 'id', 'name' )
				->setLimit( 0 )
				->execute();

			foreach ( $records as $record ) {
				$out[ (int) $record['id'] ] = $record['name'];
			}
		} catch ( \Throwable $e ) {
			// Ohne Tabelle bleiben die IDs stehen – besser als ein Abbruch.
		}

		return $out;
	}

	/** Ersetzt IDs durch Klartext, sofern die Tabelle den Wert kennt. */
	private static function apply_lookup( array $parts, array $map ) {
		$out = array();

		foreach ( $parts as $part ) {
			$id    = (int) $part;
			$out[] = isset( $map[ $id ] ) ? $map[ $id ] : $part;
		}

		return $out;
	}

	private static function bump( array &$bucket, $key ) {
		$key = (string) $key;
		if ( ! isset( $bucket[ $key ] ) ) {
			$bucket[ $key ] = 0;
		}
		$bucket[ $key ]++;
	}

	/** Macht aus einem Feldwert eine flache Liste nicht-leerer Beschriftungen. */
	private static function normalise( $value ) {
		if ( null === $value || '' === $value || array() === $value ) {
			return array();
		}

		$parts = is_array( $value ) ? $value : array( $value );
		$out   = array();

		foreach ( $parts as $part ) {
			if ( is_array( $part ) ) {
				continue;
			}
			$part = trim( (string) $part );
			if ( '' !== $part ) {
				$out[] = $part;
			}
		}

		return $out;
	}

	private static function first_scalar( array $row, ...$keys ) {
		foreach ( $keys as $key ) {
			if ( ! isset( $row[ $key ] ) ) {
				continue;
			}
			$value = $row[ $key ];
			if ( is_array( $value ) ) {
				$value = reset( $value );
			}
			$value = trim( (string) $value );
			if ( '' !== $value ) {
				return $value;
			}
		}
		return '';
	}

	private static function age_from_date( $date ) {
		if ( empty( $date ) ) {
			return null;
		}
		try {
			$birth = new DateTimeImmutable( substr( (string) $date, 0, 10 ) );
			$today = new DateTimeImmutable( 'today' );
			if ( $birth > $today ) {
				return null;
			}
			$age = (int) $birth->diff( $today )->y;
			return ( $age > 120 ) ? null : $age;
		} catch ( \Throwable $e ) {
			return null;
		}
	}

	private static function age_bracket( $age ) {
		$label = 'unter 18';
		foreach ( self::age_brackets() as $floor => $text ) {
			if ( $age >= $floor ) {
				$label = $text;
			}
		}
		return $label;
	}

	private static function sort_by_bracket( array $counts ) {
		$ordered = array();
		foreach ( self::age_brackets() as $label ) {
			if ( isset( $counts[ $label ] ) ) {
				$ordered[ $label ] = $counts[ $label ];
			}
		}
		return $ordered;
	}

	private static function median( array $numbers ) {
		if ( empty( $numbers ) ) {
			return null;
		}
		sort( $numbers );
		$count  = count( $numbers );
		$middle = intdiv( $count, 2 );

		return ( 0 === $count % 2 )
			? ( $numbers[ $middle - 1 ] + $numbers[ $middle ] ) / 2
			: $numbers[ $middle ];
	}

	/** Sortiert absteigend und fasst zu kleine Gruppen zusammen. */
	private static function sort_and_suppress( array $counts, $min_cell ) {
		arsort( $counts );

		if ( $min_cell < 2 ) {
			return $counts;
		}

		$kept      = array();
		$suppressed = 0;
		$groups     = 0;

		foreach ( $counts as $label => $count ) {
			if ( $count < $min_cell ) {
				$suppressed += $count;
				$groups++;
			} else {
				$kept[ $label ] = $count;
			}
		}

		if ( $suppressed > 0 ) {
			$kept[ sprintf( 'Zusammengefasst (%d Ausprägungen unter %d)', $groups, $min_cell ) ] = $suppressed;
		}

		return $kept;
	}

	private static function lower( $string ) {
		return function_exists( 'mb_strtolower' ) ? mb_strtolower( $string, 'UTF-8' ) : strtolower( $string );
	}

	// ---------------------------------------------------------------------
	// Ausgabe
	// ---------------------------------------------------------------------

	public static function register_menu() {
		add_menu_page(
			'Mitglieder-Statistik',
			'Mitglieder-Statistik',
			self::capability(),
			self::MENU_SLUG,
			array( __CLASS__, 'render_admin_page' ),
			'dashicons-chart-bar',
			58
		);
	}

	public static function render_admin_page() {
		if ( ! current_user_can( self::capability() ) ) {
			wp_die( 'Keine Berechtigung für diese Seite.' );
		}

		$data = self::get_data();

		echo '<div class="wrap cmst-wrap">';
		echo '<h1>Mitglieder-Statistik</h1>';

		if ( is_wp_error( $data ) ) {
			printf(
				'<div class="notice notice-error"><p>%s</p></div>',
				esc_html( $data->get_error_message() )
			);
			echo '</div>';
			return;
		}

		$refresh_url = wp_nonce_url(
			admin_url( 'admin-post.php?action=cmst_refresh' ),
			'cmst_refresh'
		);

		printf(
			'<p class="cmst-meta">Stand: %s <a class="button button-secondary" href="%s">Daten neu berechnen</a></p>',
			esc_html( wp_date( 'j. F Y, H:i', $data['generated'] ) . ' Uhr' ),
			esc_url( $refresh_url )
		);

		self::print_styles();
		echo self::render_report( $data ); // phpcs:ignore WordPress.Security.EscapeOutput
		echo '</div>';
	}

	public static function register_dashboard_widget() {
		if ( ! current_user_can( self::capability() ) ) {
			return;
		}
		wp_add_dashboard_widget(
			'cmst_dashboard_widget',
			'Mitglieder-Statistik',
			array( __CLASS__, 'render_dashboard_widget' )
		);
	}

	public static function render_dashboard_widget() {
		$data = self::get_data();

		if ( is_wp_error( $data ) ) {
			printf( '<p>%s</p>', esc_html( $data->get_error_message() ) );
			return;
		}

		self::print_styles();

		printf(
			'<p class="cmst-headline"><strong>%s</strong> Mitgliedschaften von <strong>%s</strong> Personen</p>',
			esc_html( number_format_i18n( $data['total_memberships'] ) ),
			esc_html( number_format_i18n( $data['total_contacts'] ) )
		);

		echo self::render_count_table( $data['by_status'], $data['total_memberships'], 'Status' ); // phpcs:ignore WordPress.Security.EscapeOutput

		printf(
			'<p class="cmst-meta"><a href="%s">Vollständige Auswertung ansehen</a></p>',
			esc_url( admin_url( 'admin.php?page=' . self::MENU_SLUG ) )
		);
	}

	public static function shortcode( $atts ) {
		if ( ! current_user_can( self::capability() ) ) {
			return '<p>Diese Auswertung ist nur für angemeldete Personen mit entsprechender Berechtigung sichtbar.</p>';
		}

		$data = self::get_data();

		if ( is_wp_error( $data ) ) {
			return '<p>' . esc_html( $data->get_error_message() ) . '</p>';
		}

		ob_start();
		self::print_styles();
		echo self::render_report( $data ); // phpcs:ignore WordPress.Security.EscapeOutput
		return ob_get_clean();
	}

	// ---------------------------------------------------------------------
	// Einzelauswertungen für die Website
	// ---------------------------------------------------------------------

	/**
	 * [cmst_stat typ="…" id="…" format="…" titel="…" top="…" min="…" leere="…"]
	 *
	 * Gibt eine einzelne Auswertung aus. Anders als der große Shortcode ist
	 * diese Ausgabe für alle Besucher sichtbar – sie enthält nur Summen.
	 */
	public static function shortcode_stat( $atts ) {
		$atts = shortcode_atts(
			array(
				'typ'    => 'gesamt',
				'id'     => '',
				'format' => '',
				'titel'  => '',
				'top'    => 0,
				'min'      => '',
				'leere'    => 'nein',
				'mehrfach' => 'kombination',
			),
			$atts,
			'cmst_stat'
		);

		$data = self::get_data();

		if ( is_wp_error( $data ) ) {
			// Besucher sollen keine Fehlermeldungen sehen.
			return current_user_can( self::capability() )
				? '<p class="cmst-meta">' . esc_html( $data->get_error_message() ) . '</p>'
				: '';
		}

		$series = self::build_series( $data, $atts );

		if ( null === $series ) {
			return current_user_can( self::capability() )
				? '<p class="cmst-meta">Unbekannte Auswertung. Prüfe die Angaben für „typ“ und „id“.</p>'
				: '';
		}

		ob_start();
		self::print_styles();
		$styles = ob_get_clean();

		$title = ( '' !== $atts['titel'] ) ? $atts['titel'] : $series['title'];
		$title = ( '-' === trim( $title ) ) ? '' : $title;

		return $styles . '<div class="cmst-widget">' . self::render_series( $series, $title, $atts ) . '</div>';
	}

	/**
	 * Übersetzt die Shortcode-Angaben in eine auswertbare Datenreihe.
	 *
	 * @return array|null
	 */
	private static function build_series( array $data, array $atts ) {
		$typ   = sanitize_key( $atts['typ'] );
		$id    = $atts['id'];
		$total = max( 1, (int) $data['total_memberships'] );

		switch ( $typ ) {
			case 'gesamt':
			case 'mitglieder':
				return array(
					'kind'  => 'zahl',
					'title' => apply_filters( 'cmst_total_label', 'Gut-Menschen-Partei-Mit-Glieder' ),
					'value' => number_format_i18n( $data['total_contacts'] ),
					'note'  => '',
				);

			case 'mitgliedschaften':
				return array(
					'kind'  => 'zahl',
					'title' => 'Mitgliedschaften',
					'value' => number_format_i18n( $data['total_memberships'] ),
					'note'  => '',
				);

			case 'status':
				return array(
					'kind'   => 'serie',
					'title'  => 'Status',
					'counts' => $data['by_status'],
					'total'  => $total,
					'note'   => '',
				);

			case 'geschlecht':
				// Primär aus der An-Rede, weil das CiviCRM-Standardfeld
				// „Geschlecht“ bei vielen Installationen nicht gepflegt wird.
				foreach ( $data['fields'] as $field ) {
					if ( $field['id'] === self::SALUTATION_ID ) {
						$counts = self::gender_from_salutation( $field['values'] );
						if ( ! empty( $counts ) ) {
							return array(
								'kind'   => 'serie',
								'title'  => 'Geschlecht',
								'counts' => $counts,
								'total'  => $total,
								'note'   => '',
							);
						}
					}
				}

				if ( ! is_array( $data['by_gender'] ) || empty( $data['by_gender'] ) ) {
					return null;
				}

				return array(
					'kind'   => 'serie',
					'title'  => 'Geschlecht',
					'counts' => $data['by_gender'],
					'total'  => $total,
					'note'   => '',
				);

			case 'anrede':
				foreach ( $data['fields'] as $field ) {
					if ( $field['id'] === self::SALUTATION_ID ) {
						return array(
							'kind'   => 'serie',
							'title'  => $field['label'],
							'counts' => $field['values'],
							'total'  => $total,
							'note'   => '',
						);
					}
				}
				return null;

			case 'bundesland':
			case 'bundeslaender':
				if ( ! is_array( $data['by_state'] ) ) {
					return null;
				}
				return array(
					'kind'   => 'serie',
					'title'  => 'Bundesland',
					'counts' => $data['by_state'],
					'total'  => $total,
					'note'   => '',
				);

			case 'alter':
				foreach ( $data['fields'] as $field ) {
					if ( 'age' === $field['mode'] ) {
						return array(
							'kind'    => 'alter',
							'title'   => 'Alter',
							'counts'  => $field['values'],
							'total'   => $total,
							'average' => $field['average'],
							'median'  => $field['median'],
							'min'     => $field['min'],
							'max'     => $field['max'],
							'note'    => '',
						);
					}
				}
				return null;

			case 'feld':
				$id      = (int) $id;
				$einzeln = ( 'einzeln' === self::lower( trim( (string) $atts['mehrfach'] ) ) );

				foreach ( $data['fields'] as $field ) {
					if ( $field['id'] !== $id || 'age' === $field['mode'] ) {
						continue;
					}

					$counts = $field['values'];
					$note   = '';

					if ( ! empty( $field['multiple'] ) ) {
						if ( $einzeln ) {
							$note = 'Mehrfachnennungen möglich, Summe kann über 100 % liegen';
						} elseif ( ! empty( $field['combos'] ) ) {
							$counts = $field['combos'];
						}
					}

					return array(
						'kind'   => 'serie',
						'title'  => $field['label'],
						'counts' => $counts,
						'total'  => $total,
						'note'   => $note,
					);
				}
				return null;
		}

		return null;
	}

	/** Wendet die Anzeigeoptionen an und rendert die Reihe. */
	private static function render_series( array $series, $title, array $atts ) {
		$format = sanitize_key( $atts['format'] );

		if ( 'zahl' === $series['kind'] ) {
			return self::render_number( $series['value'], $title, $series['note'] );
		}

		if ( 'alter' === $series['kind'] && in_array( $format, array( '', 'zahl', 'text' ), true ) ) {
			if ( null === $series['median'] ) {
				return '';
			}
			$note = sprintf(
				'Spanne %s bis %s Jahre, Durchschnitt %s Jahre',
				number_format_i18n( $series['min'] ),
				number_format_i18n( $series['max'] ),
				number_format_i18n( $series['average'], 1 )
			);
			return self::render_number(
				sprintf( '%s Jahre', number_format_i18n( $series['median'], 1 ) ),
				( '' === $title ) ? '' : $title . ' (Median)',
				$note
			);
		}

		$counts = self::shape_counts( $series['counts'], $atts );

		if ( empty( $counts ) ) {
			return '';
		}

		$format = ( '' === $format ) ? 'tabelle' : $format;
		$total  = max( 1, (int) $series['total'] );

		switch ( $format ) {
			case 'liste':
				$html = ( '' === $title ) ? '' : '<h3 class="cmst-block-title">' . esc_html( $title ) . '</h3>';
				if ( '' !== $series['note'] ) {
					$html .= '<p class="cmst-block-note">' . esc_html( $series['note'] ) . '</p>';
				}
				return $html . self::render_list( $counts, $total );

			case 'text':
			case 'inline':
				return self::render_inline( $counts, $total );

			case 'tabelle':
			case 'balken':
			default:
				return self::render_count_table( $counts, $total, $title, $series['note'] );
		}
	}

	/** Filtert „Keine Angabe“, fasst kleine Gruppen zusammen, kürzt auf top N. */
	private static function shape_counts( array $counts, array $atts ) {
		if ( 'ja' !== self::lower( trim( $atts['leere'] ) ) ) {
			foreach ( array_keys( $counts ) as $label ) {
				if ( self::is_muted_label( $label ) ) {
					unset( $counts[ $label ] );
				}
			}
		}

		$min = ( '' === trim( (string) $atts['min'] ) ) ? self::min_cell_size() : (int) $atts['min'];

		$counts = self::sort_and_suppress( $counts, $min );

		$top = (int) $atts['top'];

		if ( $top > 0 && count( $counts ) > $top ) {
			$kept = array_slice( $counts, 0, $top, true );
			$rest = array_sum( array_slice( $counts, $top, null, true ) );

			if ( $rest > 0 ) {
				$kept['Sonstige'] = $rest;
			}

			$counts = $kept;
		}

		return $counts;
	}

	/**
	 * Übersetzt An-Rede-Werte in Geschlechterbezeichnungen und fasst
	 * gleichbedeutende Werte zusammen. Über den Filter erweiterbar.
	 */
	private static function gender_from_salutation( array $counts ) {
		$map = apply_filters(
			'cmst_salutation_gender_map',
			array(
				'herr'   => 'Männlich',
				'mr'     => 'Männlich',
				'mr.'    => 'Männlich',
				'männl.' => 'Männlich',
				'frau'   => 'Weiblich',
				'mrs'    => 'Weiblich',
				'mrs.'   => 'Weiblich',
				'ms'     => 'Weiblich',
				'ms.'    => 'Weiblich',
				'weibl.' => 'Weiblich',
				'divers' => 'Divers',
			)
		);

		$out = array();

		foreach ( $counts as $label => $count ) {
			$key    = self::lower( trim( (string) $label ) );
			$target = isset( $map[ $key ] ) ? $map[ $key ] : $label;

			if ( ! isset( $out[ $target ] ) ) {
				$out[ $target ] = 0;
			}

			$out[ $target ] += $count;
		}

		arsort( $out );

		return $out;
	}

	private static function render_number( $value, $title, $note ) {
		$html = '<div class="cmst-number">';

		if ( '' !== $title ) {
			$html .= '<span class="cmst-number-label">' . esc_html( $title ) . '</span>';
		}

		$html .= '<span class="cmst-number-value">' . esc_html( $value ) . '</span>';

		if ( '' !== $note ) {
			$html .= '<span class="cmst-number-note">' . esc_html( $note ) . '</span>';
		}

		return $html . '</div>';
	}

	private static function render_list( array $counts, $total ) {
		$html = '<ul class="cmst-list">';

		foreach ( $counts as $label => $count ) {
			$html .= sprintf(
				'<li><span class="cmst-list-label">%s</span><span class="cmst-list-value">%s&nbsp;%%<span class="cmst-list-count"> (%s)</span></span></li>',
				esc_html( $label ),
				esc_html( number_format_i18n( ( $count / $total ) * 100, 1 ) ),
				esc_html( number_format_i18n( $count ) )
			);
		}

		return $html . '</ul>';
	}

	private static function render_inline( array $counts, $total ) {
		$parts = array();

		foreach ( $counts as $label => $count ) {
			$parts[] = sprintf(
				'%s %s %%',
				$label,
				number_format_i18n( ( $count / $total ) * 100, 1 )
			);
		}

		return '<span class="cmst-inline">' . esc_html( implode( ', ', $parts ) ) . '</span>';
	}

	public static function handle_refresh() {
		if ( ! current_user_can( self::capability() ) || ! check_admin_referer( 'cmst_refresh' ) ) {
			wp_die( 'Keine Berechtigung für diese Aktion.' );
		}

		delete_transient( self::CACHE_KEY );
		self::get_data( true );

		wp_safe_redirect( admin_url( 'admin.php?page=' . self::MENU_SLUG ) );
		exit;
	}

	/** Baut die komplette Auswertung als HTML. */
	private static function render_report( array $data ) {
		$total = max( 1, $data['total_memberships'] );
		$html  = '<div class="cmst-report">';

		$html .= '<div class="cmst-summary">';
		$html .= self::summary_card( 'Mitgliedschaften', number_format_i18n( $data['total_memberships'] ), implode( ', ', $data['status_labels'] ) );
		$html .= self::summary_card( 'Personen', number_format_i18n( $data['total_contacts'] ), 'Eindeutige Kontakte' );
		$html .= '</div>';

		$html .= self::render_count_table( $data['by_status'], $total, 'Mitgliedschaften nach Status' );

		if ( is_array( $data['by_gender'] ) && self::has_real_values( $data['by_gender'] ) ) {
			$html .= self::render_count_table( $data['by_gender'], $total, 'Mitgliedschaften nach Geschlecht (CiviCRM-Standardfeld)' );
		}

		if ( is_array( $data['by_state'] ) ) {
			$html .= self::render_count_table( $data['by_state'], $total, 'Mitgliedschaften nach Bundesland' );
		} else {
			$html .= '<p class="cmst-meta">Die Bundesland-Auswertung ist in dieser CiviCRM-Version nicht verfügbar.</p>';
		}

		if ( ! empty( $data['group_title'] ) ) {
			$html .= sprintf(
				'<p class="cmst-meta">Die folgenden Felder stammen aus der Feldgruppe „%s“ und hängen %s. %s</p>',
				esc_html( $data['group_title'] ),
				'contact' === $data['attaches_to'] ? 'am Kontakt' : 'an der Mitgliedschaft',
				'contact' === $data['attaches_to']
					? 'Personen mit mehreren Mitgliedschaften werden daher mehrfach gezählt.'
					: ''
			);
		}

		foreach ( $data['fields'] as $field ) {
			$html .= self::render_field( $field, $total );
		}

		if ( $data['min_cell'] > 1 ) {
			$html .= sprintf(
				'<p class="cmst-meta">Ausprägungen mit weniger als %d Nennungen sind zum Schutz der Betroffenen zusammengefasst.</p>',
				(int) $data['min_cell']
			);
		}

		$html .= '</div>';

		return $html;
	}

	private static function summary_card( $label, $value, $note ) {
		return sprintf(
			'<div class="cmst-card"><span class="cmst-card-label">%s</span><span class="cmst-card-value">%s</span><span class="cmst-card-note">%s</span></div>',
			esc_html( $label ),
			esc_html( $value ),
			esc_html( $note )
		);
	}

	private static function render_field( array $field, $total ) {
		$subtitle = sprintf(
			'%s ausgefüllt, %s ohne Angabe',
			number_format_i18n( $field['filled'] ),
			number_format_i18n( $field['empty'] )
		);

		$values = $field['values'];

		if ( ! empty( $field['multiple'] ) && ! empty( $field['combos'] ) ) {
			$values    = $field['combos'];
			$subtitle .= ' · Mehrfachnennungen als eigene Kategorie';
		}

		if ( 'age' === $field['mode'] && null !== $field['average'] ) {
			$subtitle .= sprintf(
				' · Durchschnitt %s Jahre, Median %s, Spanne %s–%s',
				number_format_i18n( $field['average'], 1 ),
				number_format_i18n( $field['median'], 1 ),
				number_format_i18n( $field['min'] ),
				number_format_i18n( $field['max'] )
			);
		}

		if ( 'age' === $field['mode'] ) {
			$values = $field['values'];
		}

		return self::render_count_table( $values, $total, $field['label'], $subtitle );
	}

	private static function render_count_table( array $counts, $total, $title, $subtitle = '' ) {
		$total = max( 1, (int) $total );

		$html = '<section class="cmst-block">';
		$html .= '<h2 class="cmst-block-title">' . esc_html( $title ) . '</h2>';

		if ( '' !== $subtitle ) {
			$html .= '<p class="cmst-block-note">' . esc_html( $subtitle ) . '</p>';
		}

		if ( empty( $counts ) ) {
			$html .= '<p class="cmst-block-note">Keine Werte vorhanden.</p></section>';
			return $html;
		}

		$max = max( $counts );

		$html .= '<table class="cmst-table"><thead><tr>';
		$html .= '<th scope="col">Ausprägung</th><th scope="col" class="cmst-num">Anzahl</th><th scope="col" class="cmst-num">Anteil</th><th scope="col" class="cmst-viz"><span class="screen-reader-text">Verteilung</span></th>';
		$html .= '</tr></thead><tbody>';

		foreach ( $counts as $label => $count ) {
			$share = ( $count / $total ) * 100;
			$width = ( $count / max( 1, $max ) ) * 100;
			$muted = self::is_muted_label( $label ) ? ' cmst-row-muted' : '';

			$html .= sprintf(
				'<tr class="%s"><th scope="row">%s</th><td class="cmst-num">%s</td><td class="cmst-num">%s&nbsp;%%</td><td class="cmst-viz"><span class="cmst-bar" style="width:%s%%"></span></td></tr>',
				esc_attr( trim( $muted ) ),
				esc_html( $label ),
				esc_html( number_format_i18n( $count ) ),
				esc_html( number_format_i18n( $share, 1 ) ),
				esc_attr( number_format( $width, 2, '.', '' ) )
			);
		}

		$html .= '</tbody></table></section>';

		return $html;
	}

	/** Prüft, ob eine Reihe außer „Keine Angabe“ überhaupt etwas enthält. */
	private static function has_real_values( array $counts ) {
		foreach ( $counts as $label => $count ) {
			if ( $count > 0 && ! self::is_muted_label( $label ) ) {
				return true;
			}
		}

		return false;
	}

	private static function is_muted_label( $label ) {
		$label = self::lower( (string) $label );
		return ( false !== strpos( $label, 'keine angabe' ) || false !== strpos( $label, 'zusammengefasst' ) );
	}

	/** Wandelt eine Hex-Farbe in eine rgba-Angabe mit Transparenz. */
	private static function accent_alpha( $hex, $alpha ) {
		$hex = ltrim( (string) $hex, '#' );

		if ( 3 === strlen( $hex ) ) {
			$hex = $hex[0] . $hex[0] . $hex[1] . $hex[1] . $hex[2] . $hex[2];
		}

		if ( 6 !== strlen( $hex ) || ! ctype_xdigit( $hex ) ) {
			return 'rgba(51,51,153,' . $alpha . ')';
		}

		return sprintf(
			'rgba(%d,%d,%d,%s)',
			hexdec( substr( $hex, 0, 2 ) ),
			hexdec( substr( $hex, 2, 2 ) ),
			hexdec( substr( $hex, 4, 2 ) ),
			$alpha
		);
	}

	private static function print_styles() {
		static $printed = false;
		if ( $printed ) {
			return;
		}
		$printed = true;

		// Akzentfarbe, über den Filter cmst_accent_color anpassbar.
		$accent = sanitize_hex_color( apply_filters( 'cmst_accent_color', '#333399' ) );
		$accent = $accent ? $accent : '#333399';
		$soft   = self::accent_alpha( $accent, 0.25 );
		?>
		<style id="cmst-styles">
			.cmst-report, .cmst-widget, .cmst-table, #cmst_dashboard_widget {
				--cmst-accent: <?php echo esc_html( $accent ); ?>;
				--cmst-accent-soft: <?php echo esc_html( $soft ); ?>;
			}
			.cmst-report { max-width: 60rem; }
			.cmst-summary { display: flex; flex-wrap: wrap; gap: 1rem; margin: 1.5rem 0 2rem; }
			.cmst-card { flex: 1 1 12rem; padding: 1rem 1.25rem; background: #fff; border: 1px solid #dcdcde; border-left: 4px solid var(--cmst-accent, #333399); }
			.cmst-card-label { display: block; font-size: .75rem; letter-spacing: .06em; text-transform: uppercase; color: #50575e; }
			.cmst-card-value { display: block; font-size: 2rem; font-weight: 600; line-height: 1.2; margin: .15rem 0; }
			.cmst-card-note { display: block; font-size: .8125rem; color: #50575e; }
			.cmst-block { margin: 0 0 2.25rem; }
			.cmst-block-title { font-size: 1.05rem; margin: 0 0 .25rem; padding: 0; color: var(--cmst-accent, #333399); }
			.cmst-block-note { margin: 0 0 .6rem; font-size: .8125rem; color: #50575e; }
			.cmst-table { width: 100%; border-collapse: collapse; background: #fff; border: 1px solid var(--cmst-accent, #333399); }
			.cmst-table th, .cmst-table td { padding: .45rem .7rem; text-align: left; font-weight: 400; border-bottom: 1px solid var(--cmst-accent-soft, rgba(51,51,153,.25)); }
			.cmst-table thead th { font-size: .75rem; text-transform: uppercase; letter-spacing: .05em; color: #fff; background: var(--cmst-accent, #333399); border-bottom: 0; }
			.cmst-table thead th a, .cmst-table thead th .screen-reader-text { color: #fff; }
			.cmst-table tbody tr:last-child th, .cmst-table tbody tr:last-child td { border-bottom: 0; }
			.cmst-table .cmst-num { text-align: right; white-space: nowrap; font-variant-numeric: tabular-nums; }
			.cmst-table .cmst-viz { width: 38%; }
			.cmst-bar { display: block; height: .55rem; min-width: 2px; background: var(--cmst-accent, #333399); border-radius: 2px; }
			.cmst-row-muted th, .cmst-row-muted td { color: #646970; font-style: italic; }
			.cmst-row-muted .cmst-bar { background: #c3c4c7; }
			.cmst-meta { font-size: .8125rem; color: #50575e; }
			.cmst-meta .button { margin-left: .75rem; }
			.cmst-headline { font-size: 1rem; margin: 0 0 .75rem; }
			.cmst-widget { margin: 0 0 1.5rem; }
			.cmst-number { display: block; }
			.cmst-number-label { display: block; font-size: .75rem; letter-spacing: .06em; text-transform: uppercase; color: var(--cmst-accent, #333399); }
			.cmst-number-value { display: block; font-size: 2.5rem; font-weight: 700; line-height: 1.1; color: var(--cmst-accent, #333399); }
			.cmst-number-note { display: block; font-size: .8125rem; color: var(--cmst-accent, #333399); margin-top: .15rem; }
			.cmst-list { list-style: none; margin: 0; padding: 0; }
			.cmst-list li { display: flex; justify-content: space-between; gap: 1rem; padding: .35rem 0; border-bottom: 1px solid rgba(0,0,0,.08); }
			.cmst-list li:last-child { border-bottom: 0; }
			.cmst-list-value { white-space: nowrap; font-variant-numeric: tabular-nums; font-weight: 600; }
			.cmst-list-count { font-weight: 400; opacity: .65; }
			.cmst-inline { font-variant-numeric: tabular-nums; }
			@media (max-width: 640px) {
				.cmst-table .cmst-viz { display: none; }
			}
		</style>
		<?php
	}
}

CMST_Mitglieder_Statistik::init();

register_deactivation_hook( __FILE__, function () {
	delete_transient( CMST_Mitglieder_Statistik::CACHE_KEY );
} );
